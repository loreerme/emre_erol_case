from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.support.ui import WebDriverWait
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.keys import Keys
import time
from utils.logger import get_logger
from pages.view_role import ViewRole
from selenium.webdriver.common.action_chains import ActionChains

class QAJobs:
    def __init__(self, driver):
        self.driver = driver
        self.wait = WebDriverWait(driver, 20)
        self.logger = get_logger(__name__)
        self.actions = ActionChains(self.driver)


    #Locators
    DEPARTMENT_LOAD_CHECKER = (By.CSS_SELECTOR,".select2-selection__rendered[title='Quality Assurance']")
    LOCATION_CHECKER = (By.CSS_SELECTOR,"#select2-filter-by-location-container")
    LOCATION_CONTAINER = (By.CSS_SELECTOR, "[aria-labelledby='select2-filter-by-location-container']")

    POSITION_TITLES = (By.CSS_SELECTOR,".position-title")
    POSITION_DEPARTMENTS = (By.CSS_SELECTOR,".position-department")
    POSITION_LOCATIONS = (By.CSS_SELECTOR,".position-location")

    POS_WRAPPER = (By.CSS_SELECTOR,".position-list-item-wrapper")
    POSITION_LIST = (By.CSS_SELECTOR, ".position-list")
    POSITION_ITEM = (By.CSS_SELECTOR, ".position-list-item")

    VIEW_ROLE_BUTTON = (By.CSS_SELECTOR,"a[href*='https://jobs.lever.co/useinsider']")

    def search_jobs(self):
        try:
            self.logger.info("Waiting for filters to load")
            self.wait.until(ec.visibility_of_element_located(self.DEPARTMENT_LOAD_CHECKER))
            location_titles = self.driver.find_element(*self.LOCATION_CHECKER)
            location_combobox = self.driver.find_element(*self.LOCATION_CONTAINER)
            time.sleep(1)
            self.logger.info("Searching for jobs in Istanbul, Turkiye")
            while location_titles.get_attribute("title") != "Istanbul, Turkiye":
                location_combobox.send_keys(Keys.ENTER)
                time.sleep(1)
                location_combobox.send_keys(Keys.ARROW_DOWN)
                time.sleep(1)
                location_combobox.send_keys(Keys.ENTER)
            return True
        except NoSuchElementException:
            self.logger.error("None Found")
            return False

    def check_jobs_amount (self):
        self.wait.until(ec.visibility_of_element_located(self.POSITION_LIST))
        positions_list = self.driver.find_element(*self.POSITION_LIST)
        time.sleep(5)
        positions = positions_list.find_elements(*self.POSITION_ITEM)
        self.logger.info("Checking the amount of jobs in Istanbul, Turkiye")
        job_counter = 0
        try:
            for _ in positions:
                job_counter += 1
            self.logger.info(f"Found {job_counter} jobs in Istanbul, Turkiye")
            return job_counter
        except NoSuchElementException:
            self.logger.error("None Found")
            return 0

    def check_job_title(self):
        self.wait.until(ec.visibility_of_element_located(self.POSITION_LIST))
        positions_list = self.driver.find_element(*self.POSITION_LIST)
        time.sleep(5)
        self.wait.until(ec.visibility_of_element_located(self.POSITION_ITEM))
        positions = positions_list.find_elements(*self.POSITION_ITEM)
        try:
            for position in positions:
                position_wraps = position.find_element(*self.POS_WRAPPER)
                position_title = position_wraps.find_element(*self.POSITION_TITLES)
                self.logger.info("Checking if the job title contains Quality Assurance")
                self.logger.info(f"{position_title.text}")
                if "Quality Assurance" in position_title.text :
                    self.logger.info("PASS")
                else:
                    self.logger.error("FAIL")
                    return False
            return True
        except NoSuchElementException:
            self.logger.error("Job Title not found")
            return False

    def check_job_location(self):
        self.wait.until(ec.visibility_of_element_located(self.POSITION_LIST))
        positions_list = self.driver.find_element(*self.POSITION_LIST)
        time.sleep(5)
        self.wait.until(ec.visibility_of_element_located(self.POSITION_ITEM))
        positions = positions_list.find_elements(*self.POSITION_ITEM)
        try:
            for position in positions:
                position_wraps = position.find_element(*self.POS_WRAPPER)
                position_location = position_wraps.find_element(*self.POSITION_LOCATIONS)
                self.logger.info("Checking if the job location is Istanbul, Turkiye")
                if "Istanbul, Turkiye" in position_location.text:
                    self.logger.info("PASS")
                else:
                    self.logger.error("FAIL")
                    return False
            return True
        except NoSuchElementException:
            self.logger.error("Job Location not found")
            return False

    def check_job_department(self):
        self.wait.until(ec.visibility_of_element_located(self.POSITION_LIST))
        positions_list = self.driver.find_element(*self.POSITION_LIST)
        time.sleep(5)
        self.wait.until(ec.visibility_of_element_located(self.POSITION_ITEM))
        positions = positions_list.find_elements(*self.POSITION_ITEM)
        try:
            for position in positions:
                position_wraps = position.find_element(*self.POS_WRAPPER)
                position_department = position_wraps.find_element(*self.POSITION_DEPARTMENTS)
                self.logger.info("Checking if the job department contains Quality Assurance")
                if "Quality Assurance" in position_department.text:
                    self.logger.info("PASS")
                else:
                    self.logger.error("FAIL")
                    return False
            return True
        except NoSuchElementException:
            self.logger.error("Job Department not found")
            return False

    def go_to_view_role(self):
        view_role_btn = self.driver.find_elements(*self.VIEW_ROLE_BUTTON)
        view_role = ViewRole(self.driver)
        incorrect_counter = 0
        for roles in view_role_btn:
            self.logger.info("Checking the View Role link")
            self.driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", roles)
            time.sleep(2)
            main_window = self.driver.current_window_handle
            roles.click()
            WebDriverWait(self.driver, 10).until(lambda d: len(d.window_handles) > 1)
            all_windows = self.driver.window_handles
            for handle in all_windows:
                if handle != main_window:
                    self.driver.switch_to.window(handle)
                    break
            check = view_role.check_current_page()
            view_role.close_window()
            self.driver.switch_to.window(main_window)
            if check:
                self.logger.info("PASS")
            else:
                self.logger.error("FAIL")
                incorrect_counter += 1
        return True if incorrect_counter == 0 else False






