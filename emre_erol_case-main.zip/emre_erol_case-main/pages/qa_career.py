from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.support.ui import WebDriverWait
from selenium.common.exceptions import NoSuchElementException
import time
from utils.logger import get_logger

class QACareerPage:
    def __init__(self, driver):
        self.driver = driver
        self.wait = WebDriverWait(driver, 15)
        self.logger = get_logger(__name__)

    #Locators
    QA_ALL_JOBS = (By.CSS_SELECTOR, "a[href = 'https://useinsider.com/careers/open-positions/?department=qualityassurance']")

    def go_to_qa_jobs(self):
        try:
            self.logger.info("Navigating to QA Job search page")
            self.scroll_and_click(self.QA_ALL_JOBS)
            time.sleep(1)
            self.logger.info("Opened QA Jobs search page")
            return True
        except NoSuchElementException:
            return False

    def scroll_and_click(self, locator):
        element = self.driver.find_element(*locator)
        self.driver.execute_script("arguments[0].scrollIntoView({behavior: 'auto', block: 'center'});", element)
        time.sleep(1)  # Let animations complete
        self.wait.until(ec.element_to_be_clickable(locator)).click()



