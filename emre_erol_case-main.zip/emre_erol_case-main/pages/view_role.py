from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.support.ui import WebDriverWait
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.keys import Keys
import time
from utils.logger import get_logger


class ViewRole(object):
    def __init__(self, driver):
        self.driver = driver
        self.wait = WebDriverWait(driver, 20)
        self.logger = get_logger(__name__)


    LEVER_WEBSITE_CHECK = (By.CSS_SELECTOR, "a[href='https://jobs.lever.co/useinsider']")
    APP_FORM = (By.CSS_SELECTOR, "#application-form")

    def check_current_page(self):
        self.logger.info("Checking if the current page has job application form")
        self.logger.info("First checking if the current page is Lever job application website")
        self.wait.until(ec.visibility_of_element_located(self.LEVER_WEBSITE_CHECK))
        try:
            if (self.driver.find_element(*self.LEVER_WEBSITE_CHECK)) is not None:
                self.logger.info("It is the Lever job application website")
                self.logger.info("Now checking if the job application form exists on this page")
                try:
                    if self.driver.find_element(*self.APP_FORM) is not None:
                        self.logger.info("PASS")
                        return True
                    else:
                        self.logger.info("FAIL")
                        return False
                except NoSuchElementException:
                    self.logger.info("FAIL")
                    return False
        except NoSuchElementException:
            self.logger.info("FAIL")
            return False

    def close_window(self):
        self.logger.info("Closing the current Lever Job page")
        self.driver.close()




