from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.support.ui import WebDriverWait
from selenium.common.exceptions import TimeoutException, NoSuchElementException
import time
from utils.logger import get_logger

class CareerPage:
    def __init__(self, driver):
        self.driver = driver
        self.wait = WebDriverWait(driver, 15)
        self.logger = get_logger(__name__)

    #LOCATORS
    TEAMS = (By.CSS_SELECTOR, "#career-find-our-calling")
    LOCATIONS = (By.CSS_SELECTOR,"#career-our-location.overflow-hidden")
    LIFE_AT_INSIDER = (By.CSS_SELECTOR,".elementor-column[data-id='87842ec']")
    TEAMS_EXPAND = (By.CSS_SELECTOR, "#career-find-our-calling>.container>.row>a.btn[href*='javascript:void(0)']")
    QUALITY_ASSURANCE = (By.CSS_SELECTOR,".job-title>a[href*='https://useinsider.com/careers/quality-assurance']")


    def wait_for_locations(self):
        try:
            self.logger.info("Checking if Locations block exists")
            self.wait.until(ec.visibility_of_element_located(self.LOCATIONS))
            return True
        except TimeoutException:
            self.logger.error("Cannot validate if Locations block exists")
            return False

    def wait_for_teams(self):
        try:
            self.logger.info("Checking if Teams block exists")
            self.wait.until(ec.visibility_of_element_located(self.TEAMS))
            return True
        except TimeoutException:
            self.logger.error("Cannot validate if Teams block exists")
            return False

    def wait_for_life_at_insider(self):
        try:
            self.logger.info("Checking if Life at Insider block exists")
            self.wait.until(ec.visibility_of_element_located(self.LIFE_AT_INSIDER))
            return True
        except TimeoutException:
            self.logger.error("Cannot validate if Life at Insider block exists")
            return False

    def go_to_qa(self):
        self.wait_for_teams()
        try:
            self.scroll_and_click(self.TEAMS_EXPAND) # Click See all Teams to expand, to make QA Page available
            time.sleep(1)
            self.logger.info("Navigating to QA Jobs main page")
            self.scroll_and_click(self.QUALITY_ASSURANCE)
            self.logger.info("Opened QA Jobs main page")
            return True
        except NoSuchElementException:
            self.logger.error("Cannot navigate to QA Jobs main page")
            return False

    def scroll_and_click(self, locator):
        element = self.driver.find_element(*locator)
        self.driver.execute_script("arguments[0].scrollIntoView({behavior: 'auto', block: 'center'});", element) # Scroll to element to make it interactable
        time.sleep(1)  # Let scroll animations complete
        self.wait.until(ec.element_to_be_clickable(locator)).click()

