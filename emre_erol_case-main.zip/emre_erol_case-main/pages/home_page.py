from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.support.ui import WebDriverWait
from selenium.common.exceptions import TimeoutException
from utils.logger import get_logger
import time

class HomePage:
    def __init__(self, driver):
        self.driver = driver
        self.wait = WebDriverWait(driver, 10)
        self.logger = get_logger(__name__)

    # Locators
    LOGO = (By.CSS_SELECTOR, "a.navbar-brand")
    NAVIGATION_IDS = (By.CSS_SELECTOR, "#navbarDropdownMenuLink")
    CAREERS_LINK = (By.CSS_SELECTOR, "a[href*='https://useinsider.com/careers/']")
    HOME_LOGO = (By.CSS_SELECTOR, ".navbar-brand[href='/']")

    # Actions
    def open(self):
        self.logger.info("Opening home page")
        self.driver.get("https://useinsider.com")
        time.sleep(2)

    # Validations
    def is_url_correct(self):
        self.logger.info("Checking if url is correct for home page")
        first_title = self.driver.title # Title of the page when first opened using the link useinsider.com
        self.driver.find_element(*self.HOME_LOGO).click()
        return  self.driver.title == first_title # After clicking the logo retrieve the new title and compare it to the previous one
                                                     # If they are the same, then it means the first time we opened the website it was really the home page

    def go_to_careers(self):
        try:
            self.logger.info("Checking the availability of navigation to careers page")
            self.wait.until(ec.visibility_of_element_located(self.NAVIGATION_IDS))
        except TimeoutException:
            self.logger.error("Timed out waiting for page to load, no way to navigate to careers page")
            return False
        finally:
            self.logger.info("Navigating to careers page")
            navigation = self.driver.find_elements(*self.NAVIGATION_IDS)
            for link in navigation:
                if "Company" in link.text:
                    link.click()
            careers = self.driver.find_element(*self.CAREERS_LINK)
            careers.click()