import pytest
from selenium import webdriver
from pages.home_page import HomePage
from pages.career_page import CareerPage
import time
from pages.qa_career import QACareerPage
from pages.qa_job_search import QAJobs
from selenium.webdriver.chrome.options import Options
from utils.logger import get_logger


logger = get_logger(__name__)

@pytest.fixture
def driver():
    chrome_options = Options()
    chrome_options.add_argument("--log-level=3")
    driver = webdriver.Chrome( options=chrome_options)
    time.sleep(1)
    driver.maximize_window()
    yield driver
    driver.quit()

def test_home_page_loads_correctly(driver):
    home = HomePage(driver)
    home.open()
    time.sleep(1)

    assert home.is_url_correct(), "FAILED : Home page does not load correctly"

def test_career_sections_visible(driver):
    results = []
    home = HomePage(driver)
    careers = CareerPage(driver)
    time.sleep(1)
    home.open()
    home.go_to_careers()
    try:
        assert careers.wait_for_locations()
        results.append("PASSED : Locations section is visible")
    except AssertionError:
        results.append("FAILED : Locations section is not visible")
    try:
        assert careers.wait_for_teams()
        results.append("PASSED : Teams section is visible")
    except AssertionError:
        results.append("FAILED : Teams section is not visible")
    try:
        assert careers.wait_for_life_at_insider()
        results.append("PASSED : Life at Insider section is visible")
    except AssertionError:
        results.append("FAILED : Life at Insider section is not visible")
    for r in results:
        print(r)


def test_filter_qa_jobs(driver):
    results = []
    home = HomePage(driver)
    careers = CareerPage(driver)
    qa_main = QACareerPage(driver)
    qa_jobs = QAJobs(driver)
    time.sleep(1)
    home.open()
    home.go_to_careers()
    careers.go_to_qa()
    qa_main.go_to_qa_jobs()

    try:
        assert qa_jobs.search_jobs()
        results.append("PASSED : Teams section is expandable and QA jobs page is reachable")
    except AssertionError:
        results.append("FAILED : Teams section is not expandable or QA jobs page is not reachable")
    try:
        assert qa_jobs.check_jobs_amount()>0
        results.append("PASSED : Jobs found in Istanbul")
    except AssertionError:
        results.append("FAILED : Jobs not found in Istanbul")

    for r in results:
        print(r)

def test_job_details(driver):
    home = HomePage(driver)
    careers = CareerPage(driver)
    qa_main = QACareerPage(driver)
    qa_jobs = QAJobs(driver)
    home.open()
    home.go_to_careers()
    careers.go_to_qa()
    qa_main.go_to_qa_jobs()
    qa_jobs.search_jobs()

    assert qa_jobs.check_job_title(), "FAILED : At least one job title does not contain Quality Assurance"
    assert qa_jobs.check_job_location(), "FAILED : At least one job location is not Istanbul, Turkiye"
    assert qa_jobs.check_job_department(), "FAILED : At least one job department is not Quality Assurance"
    

def test_view_role_link(driver):

    home = HomePage(driver)
    careers = CareerPage(driver)
    qa_main = QACareerPage(driver)
    qa_jobs = QAJobs(driver)
    home.open()
    home.go_to_careers()
    careers.go_to_qa()
    qa_main.go_to_qa_jobs()
    qa_jobs.search_jobs()
    time.sleep(3)
    assert qa_jobs.go_to_view_role() ,"FAILED : At least one of the View Role links did not redirect to Lever Job Application Form"
